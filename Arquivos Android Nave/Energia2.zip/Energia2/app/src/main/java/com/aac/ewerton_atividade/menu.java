package com.aac.ewerton_atividade;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }
    public void trocarTela1(View v)
    {
        Intent troca = new Intent(this, MainActivity2.class);
        startActivity(troca);
    }
    public void trocarTela2(View v)
    {
        Intent troca = new Intent(this, MainActivity3.class);
        startActivity(troca);
    }
    public void trocarTela3(View v)
    {
        Intent troca = new Intent(this, MainActivity4.class);
        startActivity(troca);
    }
    public void trocarTela4(View v)
    {
        Intent troca = new Intent(this, MainActivity5.class);
        startActivity(troca);
    }
}

