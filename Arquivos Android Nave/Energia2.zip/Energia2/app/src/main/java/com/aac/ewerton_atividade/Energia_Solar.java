package com.aac.ewerton_atividade;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Energia_Solar extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_energia__solar);
    }
    public void trocarTela(View v)
    {
        Intent troca = new Intent(this, menu.class);
        startActivity(troca);
    }
}
